export const environment = {
  production: true,
  location: 'Development',
  apiUrl: 'http://my-api-url'
};
